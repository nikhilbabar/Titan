import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LocationComponent } from './location/location.component';
import { PersonnelComponent } from './personnel/personnel.component';

const routes: Routes = [
  { path: 'location', component: LocationComponent },
  { path: 'personnel', component: PersonnelComponent }
];


@NgModule({
  declarations: [LocationComponent, PersonnelComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CorpusModule { }
