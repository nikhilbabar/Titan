import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PlaygroundComponent } from './playground/playground.component';
import { HomeComponent } from './home/home.component';
import { CorpusModule } from './corpus/corpus.module';
import { LocationComponent } from './corpus/location/location.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  {
    path: 'corpus', loadChildren:
      () => import('./corpus/corpus.module')
              .then(module => module.CorpusModule)
  },
  { path: 'playground', component: PlaygroundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
